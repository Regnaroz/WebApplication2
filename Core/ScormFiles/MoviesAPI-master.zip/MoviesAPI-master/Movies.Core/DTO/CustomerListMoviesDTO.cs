﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Core.DTO
{
    public class CustomerListMoviesDTO
    {
        public string Name { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public int watched { get; set; }
    }
}
