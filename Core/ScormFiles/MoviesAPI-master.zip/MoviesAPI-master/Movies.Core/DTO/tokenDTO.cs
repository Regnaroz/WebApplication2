﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Core.DTO
{
   public class tokenDTO
    {
        public string tokenValue { get; set; }
    }
}
