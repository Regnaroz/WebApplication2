﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Core.DTO
{
    public class AuthDTO
    {
        public string userName { get; set; }
        public int departmentId { get; set; }
        public int customerId { get; set; }
        public int accountantId { get; set; }
    }
}
