﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Core.DTO
{
    public class NameVerificationDTO
    {
        public string userName { get; set; }
        public int vertification { get; set; }
    }
}
