﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Core.DTO
{
    public class insertLoginResult
    {
        //test for git push
        public  bool result { get; set; }
    }
}
