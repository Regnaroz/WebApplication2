﻿using System;

namespace Movies.Core
{
    public class Class1
    {
    }
}
