﻿using System;

namespace Movies.Infra
{
    public class Class1
    {
    }
}
